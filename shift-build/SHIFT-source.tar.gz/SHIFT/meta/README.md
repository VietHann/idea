# SHIFT

A Flutter iOS photo-depth playground by **VietHannn**.

Core interactions:
- Import a photo with the iOS Photos picker.
- On-device Vision person segmentation into background + transparent foreground.
- Depth parallax controlled by drag or device tilt.
- Interactive light orb with warmth/intensity.
- Foreground/background focus blur.
- Motion presets: Drift, Push, Float.
- Save composed PNG to Photos.
- Render a 4-second H.264 MP4 with Core Image + AVAssetWriter and save to Photos.
- Local scene gallery; no backend/account/network required.
