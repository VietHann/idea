import Flutter
import UIKit
import PhotosUI
import Photos
import Vision
import CoreImage
import CoreMotion
import AVFoundation
import UniformTypeIdentifiers

@main
@objc class AppDelegate: FlutterAppDelegate, PHPickerViewControllerDelegate {
    private var pendingPickerResult: FlutterResult?
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private let motionHandler = ShiftMotionStreamHandler()

    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        GeneratedPluginRegistrant.register(with: self)

        guard let controller = window?.rootViewController as? FlutterViewController else {
            return super.application(application, didFinishLaunchingWithOptions: launchOptions)
        }

        let channel = FlutterMethodChannel(name: "shift/native", binaryMessenger: controller.binaryMessenger)
        channel.setMethodCallHandler { [weak self] call, result in
            guard let self else { return }
            switch call.method {
            case "documentsDirectory":
                result(self.documentsURL().path)
            case "pickImage":
                self.presentPicker(result: result)
            case "prepareScene":
                guard let args = call.arguments as? [String: Any], let path = args["path"] as? String else {
                    result(FlutterError(code: "bad_args", message: "Missing image path", details: nil))
                    return
                }
                self.prepareScene(path: path, result: result)
            case "saveToPhotos":
                guard let args = call.arguments as? [String: Any],
                      let path = args["path"] as? String,
                      let video = args["video"] as? Bool else {
                    result(FlutterError(code: "bad_args", message: "Missing export path", details: nil))
                    return
                }
                self.saveToPhotos(path: path, video: video, result: result)
            case "exportMotionVideo":
                guard let args = call.arguments as? [String: Any] else {
                    result(FlutterError(code: "bad_args", message: "Missing video arguments", details: nil))
                    return
                }
                self.exportVideo(args: args, result: result)
            default:
                result(FlutterMethodNotImplemented)
            }
        }

        let motionChannel = FlutterEventChannel(name: "shift/motion", binaryMessenger: controller.binaryMessenger)
        motionChannel.setStreamHandler(motionHandler)

        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }

    private func documentsURL() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func presentPicker(result: @escaping FlutterResult) {
        guard pendingPickerResult == nil else {
            result(FlutterError(code: "picker_busy", message: "Photo picker is already open", details: nil))
            return
        }
        pendingPickerResult = result
        var configuration = PHPickerConfiguration(photoLibrary: .shared())
        configuration.filter = .images
        configuration.selectionLimit = 1
        configuration.preferredAssetRepresentationMode = .current
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        window?.rootViewController?.present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        guard let callback = pendingPickerResult else { return }
        pendingPickerResult = nil
        guard let item = results.first?.itemProvider else {
            callback(nil)
            return
        }
        guard item.hasItemConformingToTypeIdentifier(UTType.image.identifier) else {
            callback(FlutterError(code: "not_image", message: "Selected item is not an image", details: nil))
            return
        }
        item.loadFileRepresentation(forTypeIdentifier: UTType.image.identifier) { [weak self] url, error in
            guard let self else { return }
            if let error {
                DispatchQueue.main.async {
                    callback(FlutterError(code: "picker_load", message: error.localizedDescription, details: nil))
                }
                return
            }
            guard let url else {
                DispatchQueue.main.async { callback(nil) }
                return
            }
            do {
                let directory = self.documentsURL().appendingPathComponent("Imports", isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let ext = url.pathExtension.isEmpty ? "jpg" : url.pathExtension
                let destination = directory.appendingPathComponent("\(UUID().uuidString).\(ext)")
                if FileManager.default.fileExists(atPath: destination.path) {
                    try FileManager.default.removeItem(at: destination)
                }
                try FileManager.default.copyItem(at: url, to: destination)
                DispatchQueue.main.async { callback(destination.path) }
            } catch {
                DispatchQueue.main.async {
                    callback(FlutterError(code: "picker_copy", message: error.localizedDescription, details: nil))
                }
            }
        }
    }

    private func prepareScene(path: String, result: @escaping FlutterResult) {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            do {
                let inputURL = URL(fileURLWithPath: path)
                guard let original = CIImage(contentsOf: inputURL, options: [.applyOrientationProperty: true]) else {
                    throw ShiftError.message("Could not read the selected photo")
                }
                let sceneDirectory = self.documentsURL()
                    .appendingPathComponent("Scenes", isDirectory: true)
                    .appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: sceneDirectory, withIntermediateDirectories: true)

                let originalURL = sceneDirectory.appendingPathComponent("original.jpg")
                let foregroundURL = sceneDirectory.appendingPathComponent("foreground.png")
                let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!
                try self.ciContext.writeJPEGRepresentation(
                    of: original,
                    to: originalURL,
                    colorSpace: colorSpace,
                    options: [.lossyCompressionQuality: 0.96]
                )

                let mask = try self.subjectMask(for: original)
                let transparent = CIImage(color: .clear).cropped(to: original.extent)
                guard let blend = CIFilter(name: "CIBlendWithMask") else {
                    throw ShiftError.message("Could not create depth layers")
                }
                blend.setValue(original, forKey: kCIInputImageKey)
                blend.setValue(transparent, forKey: kCIInputBackgroundImageKey)
                blend.setValue(mask, forKey: kCIInputMaskImageKey)
                guard let foreground = blend.outputImage?.cropped(to: original.extent) else {
                    throw ShiftError.message("Could not create foreground layer")
                }
                try self.ciContext.writePNGRepresentation(
                    of: foreground,
                    to: foregroundURL,
                    format: .RGBA8,
                    colorSpace: colorSpace
                )

                DispatchQueue.main.async {
                    result(["original": originalURL.path, "foreground": foregroundURL.path])
                }
            } catch {
                DispatchQueue.main.async {
                    result(FlutterError(code: "prepare_failed", message: error.localizedDescription, details: nil))
                }
            }
        }
    }

    private func subjectMask(for image: CIImage) throws -> CIImage {
        let request = VNGeneratePersonSegmentationRequest()
        request.qualityLevel = .accurate
        request.outputPixelFormat = kCVPixelFormatType_OneComponent8
        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        try handler.perform([request])

        if let observation = request.results?.first {
            let rawMask = CIImage(cvPixelBuffer: observation.pixelBuffer)
            let sx = image.extent.width / rawMask.extent.width
            let sy = image.extent.height / rawMask.extent.height
            let scaled = rawMask.transformed(by: CGAffineTransform(scaleX: sx, y: sy))
            if let blur = CIFilter(name: "CIGaussianBlur") {
                blur.setValue(scaled, forKey: kCIInputImageKey)
                blur.setValue(2.2, forKey: kCIInputRadiusKey)
                return (blur.outputImage ?? scaled).cropped(to: image.extent)
            }
            return scaled.cropped(to: image.extent)
        }

        let radius = min(image.extent.width, image.extent.height)
        guard let radial = CIFilter(name: "CIRadialGradient") else {
            throw ShiftError.message("No subject found")
        }
        radial.setValue(CIVector(x: image.extent.midX, y: image.extent.midY), forKey: "inputCenter")
        radial.setValue(radius * 0.16, forKey: "inputRadius0")
        radial.setValue(radius * 0.48, forKey: "inputRadius1")
        radial.setValue(CIColor(red: 1, green: 1, blue: 1, alpha: 1), forKey: "inputColor0")
        radial.setValue(CIColor(red: 0, green: 0, blue: 0, alpha: 1), forKey: "inputColor1")
        return (radial.outputImage ?? CIImage(color: .white)).cropped(to: image.extent)
    }

    private func saveToPhotos(path: String, video: Bool, result: @escaping FlutterResult) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized || status == .limited else {
                DispatchQueue.main.async {
                    result(FlutterError(code: "photo_denied", message: "Allow Photos access to save exports", details: nil))
                }
                return
            }
            let url = URL(fileURLWithPath: path)
            PHPhotoLibrary.shared().performChanges {
                if video {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                } else {
                    PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: url)
                }
            } completionHandler: { success, error in
                DispatchQueue.main.async {
                    if success {
                        result(nil)
                    } else {
                        result(FlutterError(code: "photo_save", message: error?.localizedDescription ?? "Could not save export", details: nil))
                    }
                }
            }
        }
    }

    private func exportVideo(args: [String: Any], result: @escaping FlutterResult) {
        guard let originalPath = args["originalPath"] as? String,
              let foregroundPath = args["foregroundPath"] as? String,
              let outputPath = args["outputPath"] as? String else {
            result(FlutterError(code: "bad_args", message: "Missing video paths", details: nil))
            return
        }
        let depth = (args["depth"] as? NSNumber)?.doubleValue ?? 0.55
        let lightX = (args["lightX"] as? NSNumber)?.doubleValue ?? 0.7
        let lightY = (args["lightY"] as? NSNumber)?.doubleValue ?? 0.25
        let lightIntensity = (args["lightIntensity"] as? NSNumber)?.doubleValue ?? 0.45
        let focusBlur = (args["focusBlur"] as? NSNumber)?.doubleValue ?? 8
        let preset = args["preset"] as? String ?? "drift"

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let exporter = ShiftVideoExporter(context: self.ciContext)
                let url = try exporter.export(
                    originalURL: URL(fileURLWithPath: originalPath),
                    foregroundURL: URL(fileURLWithPath: foregroundPath),
                    outputURL: URL(fileURLWithPath: outputPath),
                    depth: depth,
                    lightX: lightX,
                    lightY: lightY,
                    lightIntensity: lightIntensity,
                    focusBlur: focusBlur,
                    preset: preset
                )
                DispatchQueue.main.async { result(url.path) }
            } catch {
                DispatchQueue.main.async {
                    result(FlutterError(code: "video_export", message: error.localizedDescription, details: nil))
                }
            }
        }
    }
}

private final class ShiftMotionStreamHandler: NSObject, FlutterStreamHandler {
    private let manager = CMMotionManager()

    func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        guard manager.isDeviceMotionAvailable else { return nil }
        manager.deviceMotionUpdateInterval = 1.0 / 30.0
        manager.startDeviceMotionUpdates(to: .main) { motion, error in
            if let error {
                events(FlutterError(code: "motion", message: error.localizedDescription, details: nil))
                return
            }
            guard let attitude = motion?.attitude else { return }
            events(["roll": attitude.roll, "pitch": attitude.pitch])
        }
        return nil
    }

    func onCancel(withArguments arguments: Any?) -> FlutterError? {
        manager.stopDeviceMotionUpdates()
        return nil
    }
}

private final class ShiftVideoExporter {
    private let context: CIContext
    private let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!

    init(context: CIContext) {
        self.context = context
    }

    func export(
        originalURL: URL,
        foregroundURL: URL,
        outputURL: URL,
        depth: Double,
        lightX: Double,
        lightY: Double,
        lightIntensity: Double,
        focusBlur: Double,
        preset: String
    ) throws -> URL {
        guard let original = CIImage(contentsOf: originalURL, options: [.applyOrientationProperty: true]),
              let foreground = CIImage(contentsOf: foregroundURL, options: [.applyOrientationProperty: true]) else {
            throw ShiftError.message("Could not load scene layers")
        }

        try? FileManager.default.removeItem(at: outputURL)
        let source = original.extent.size
        let maxSide: CGFloat = 1080
        let ratio = min(1, maxSide / max(source.width, source.height))
        let width = max(2, Int((source.width * ratio).rounded()) / 2 * 2)
        let height = max(2, Int((source.height * ratio).rounded()) / 2 * 2)
        let renderSize = CGSize(width: width, height: height)
        let renderRect = CGRect(origin: .zero, size: renderSize)

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 7_000_000,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = false
        let attributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:]
        ]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attributes)
        guard writer.canAdd(input) else { throw ShiftError.message("Could not configure video writer") }
        writer.add(input)
        guard writer.startWriting() else { throw writer.error ?? ShiftError.message("Could not start video export") }
        writer.startSession(atSourceTime: .zero)

        let totalFrames = 120
        for frame in 0..<totalFrames {
            while !input.isReadyForMoreMediaData {
                Thread.sleep(forTimeInterval: 0.003)
            }
            guard let pool = adaptor.pixelBufferPool else { throw ShiftError.message("Video buffer unavailable") }
            var maybeBuffer: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &maybeBuffer)
            guard let buffer = maybeBuffer else { throw ShiftError.message("Could not allocate video frame") }

            let progress = Double(frame) / Double(totalFrames - 1)
            let t = progress * Double.pi * 2
            let movement: (Double, Double, Double)
            switch preset {
            case "push":
                movement = (sin(t) * 0.24, sin(t * 0.5) * 0.08, 1.03 + (0.5 + 0.5 * sin(t - Double.pi / 2)) * 0.055)
            case "float":
                movement = (sin(t) * 0.48, cos(t) * 0.46, 1.02)
            default:
                movement = (sin(t) * 0.72, cos(t * 0.7) * 0.22, 1.02)
            }

            let frameImage = compose(
                original: original,
                foreground: foreground,
                renderSize: renderSize,
                x: movement.0,
                y: movement.1,
                baseScale: movement.2,
                depth: depth,
                lightX: lightX,
                lightY: lightY,
                lightIntensity: lightIntensity,
                focusBlur: focusBlur
            )
            context.render(frameImage, to: buffer, bounds: renderRect, colorSpace: colorSpace)
            let time = CMTime(value: Int64(frame), timescale: 30)
            if !adaptor.append(buffer, withPresentationTime: time) {
                throw writer.error ?? ShiftError.message("Could not write video frame")
            }
        }

        input.markAsFinished()
        let semaphore = DispatchSemaphore(value: 0)
        writer.finishWriting { semaphore.signal() }
        semaphore.wait()
        if writer.status != .completed {
            throw writer.error ?? ShiftError.message("Video export did not finish")
        }
        return outputURL
    }

    private func fitCover(_ image: CIImage, to size: CGSize) -> CIImage {
        let source = image.extent
        let scale = max(size.width / source.width, size.height / source.height)
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let x = (size.width - scaled.extent.width) / 2 - scaled.extent.minX
        let y = (size.height - scaled.extent.height) / 2 - scaled.extent.minY
        return scaled.transformed(by: CGAffineTransform(translationX: x, y: y))
    }

    private func transformed(_ image: CIImage, scale: CGFloat, x: CGFloat, y: CGFloat, renderSize: CGSize) -> CIImage {
        let center = CGPoint(x: renderSize.width / 2, y: renderSize.height / 2)
        var transform = CGAffineTransform(translationX: center.x, y: center.y)
        transform = transform.scaledBy(x: scale, y: scale)
        transform = transform.translatedBy(x: -center.x, y: -center.y)
        transform = transform.translatedBy(x: x, y: y)
        return image.transformed(by: transform)
    }

    private func blur(_ image: CIImage, radius: Double, crop: CGRect) -> CIImage {
        guard radius > 0.1, let filter = CIFilter(name: "CIGaussianBlur") else { return image }
        filter.setValue(image, forKey: kCIInputImageKey)
        filter.setValue(radius, forKey: kCIInputRadiusKey)
        return (filter.outputImage ?? image).cropped(to: crop)
    }

    private func compose(
        original: CIImage,
        foreground: CIImage,
        renderSize: CGSize,
        x: Double,
        y: Double,
        baseScale: Double,
        depth: Double,
        lightX: Double,
        lightY: Double,
        lightIntensity: Double,
        focusBlur: Double
    ) -> CIImage {
        let crop = CGRect(origin: .zero, size: renderSize)
        let baseBG = fitCover(original, to: renderSize)
        let baseFG = fitCover(foreground, to: renderSize)
        let bgScale = CGFloat(baseScale + 0.055 + depth * 0.045)
        let fgScale = CGFloat(baseScale + 0.075 + depth * 0.075)
        let bg = transformed(
            baseBG,
            scale: bgScale,
            x: CGFloat(-x * 10 * depth),
            y: CGFloat(-y * 7 * depth),
            renderSize: renderSize
        )
        let fg = transformed(
            baseFG,
            scale: fgScale,
            x: CGFloat(x * 24 * depth),
            y: CGFloat(y * 15 * depth),
            renderSize: renderSize
        )

        let processedBG = focusBlur > 0 ? blur(bg, radius: focusBlur, crop: crop) : bg
        let processedFG = focusBlur < 0 ? blur(fg, radius: abs(focusBlur) * 0.78, crop: crop) : fg
        let scene: CIImage
        if let compositor = CIFilter(name: "CISourceOverCompositing") {
            compositor.setValue(processedFG, forKey: kCIInputImageKey)
            compositor.setValue(processedBG, forKey: kCIInputBackgroundImageKey)
            scene = (compositor.outputImage ?? processedBG).cropped(to: crop)
        } else {
            scene = processedFG.composited(over: processedBG).cropped(to: crop)
        }

        guard lightIntensity > 0.01, let radial = CIFilter(name: "CIRadialGradient") else {
            return scene.cropped(to: crop)
        }
        radial.setValue(CIVector(x: lightX * renderSize.width, y: (1 - lightY) * renderSize.height), forKey: "inputCenter")
        radial.setValue(0, forKey: "inputRadius0")
        radial.setValue(max(renderSize.width, renderSize.height) * 0.72, forKey: "inputRadius1")
        radial.setValue(CIColor(red: 1, green: 0.90, blue: 0.72, alpha: min(0.38, lightIntensity * 0.34)), forKey: "inputColor0")
        radial.setValue(CIColor(red: 1, green: 0.84, blue: 0.66, alpha: 0), forKey: "inputColor1")
        let glow = (radial.outputImage ?? CIImage(color: .clear)).cropped(to: crop)
        return glow.composited(over: scene).cropped(to: crop)
    }
}

private enum ShiftError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        }
    }
}
