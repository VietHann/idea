import math, os
W=H=1024
out='AppIcon.ppm'
with open(out,'wb') as f:
    f.write(f'P6\n{W} {H}\n255\n'.encode())
    for y in range(H):
        row=bytearray()
        for x in range(W):
            # creamy pink-lavender gradient
            t=x/(W-1); u=y/(H-1)
            r=int(255*(1-.08*u))
            g=int(219 + 22*(1-t) + 8*u)
            b=int(231 + 22*t)
            # soft mint blob in lower right
            dx=(x-760)/310; dy=(y-750)/300
            blob=max(0,1-(dx*dx+dy*dy))
            r=int(r*(1-.24*blob)+190*.24*blob)
            g=int(g*(1-.24*blob)+241*.24*blob)
            b=int(b*(1-.24*blob)+221*.24*blob)
            # dark rounded S-ish diagonal ribbon via distance to sin curve
            cx = 512 + 155*math.sin((y-512)/190)
            d=abs(x-cx)
            ribbon=max(0,1-d/74)
            if 235<y<805:
                r=int(r*(1-ribbon)+34*ribbon)
                g=int(g*(1-ribbon)+30*ribbon)
                b=int(b*(1-ribbon)+43*ribbon)
            row += bytes((max(0,min(255,r)),max(0,min(255,g)),max(0,min(255,b))))
        f.write(row)
print(out)
